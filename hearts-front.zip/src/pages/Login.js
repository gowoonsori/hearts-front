import { Box, Button, Container, Typography } from '@material-ui/core';
import { useCallback } from 'react';
import { useRecoilValue } from 'recoil';
import instance from '../atoms/axios';
import '../css/image.css';

const Login = () => {
   const axios = useRecoilValue(instance);

  const loginEvent = useCallback(()=>{
    axios.get('/login/saramin').then((res) => console.log(res)).catch((e)=> console.log(e));
  },[]);
  
  return (
    <Container sx={{ background: '#030303', height: '100%', m: 'auto 0', color: '#d7dadc' }} maxWidth={false}>
      <Box sx={{ display: 'flex', height: '100%' }}>
        <img src="/images/saramin.png" alt="saramin" className="img"></img>
        <Box sx={{ p: 4, textAlign: 'center', height: '100%' }}>
          <Typography sx={{ minWidth: '300px', maxWidth: '800px', m: 10, mt: 22, textAlign: 'left', fontWeight: 900, fontSize: '3em' }} variant="h1">
            서비스를 이용하려면 로그인이 필요합니다.
          </Typography>
          <Button sx={{ mr: 6, width: '60%', borderRadius: '15px', border: '1px solid #4776ee', color: '#4776ee', fontWeight: 'bold' }} onClick={loginEvent}>로그인</Button>
        </Box>
      </Box>
    </Container>
  );
};

export default Login;
